/*  Labels
------------------------------------ */

.fl-node-<?php echo $id; ?> .fl-tabs-label.fl-tab-active {
	border-color: #<?php echo $settings->border_color; ?>;
}

/*  Panels
------------------------------------ */

.fl-node-<?php echo $id; ?> .fl-tabs-panels,
.fl-node-<?php echo $id; ?> .fl-tabs-panel {
	border-color: #<?php echo $settings->border_color; ?>;
}