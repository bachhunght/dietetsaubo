<?php

if(class_exists('FLUpdater')) {
	FLUpdater::add_product(array(
		'name'      => 'Beaver Builder Plugin (Pro Version)', 
		'version'   => '1.8', 
		'slug'      => 'bb-plugin',
		'type'      => 'plugin'
	)); 
}