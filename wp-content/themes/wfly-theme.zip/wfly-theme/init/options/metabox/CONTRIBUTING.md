### The issues section is for bug reports and feature requests only. If you need help, please use [stackoverflow](http://stackoverflow.com/search?q=cmb).

**Note: all future development will continue on [CMB2](https://github.com/WebDevStudios/CMB2). Please see [that repo's CONTRIBUTING.md](https://github.com/WebDevStudios/CMB2/blob/master/CONTRIBUTING.md)**

All future Pull Requests and Issues will be directed here.
